/*!
 * @name 多平台聚合音源
 * @version 1.0.0
 * @author HYWmusic
 * @description 多平台聚合音源 - 支持酷我、QQ音乐、网易云音乐（含高音质）
 *
 * 支持平台: 酷我、QQ、网易云
 * 支持音质: 128k、320k、flac、flac24bit、hires、atmos、atmos_plus、master
 * 生成时间: 2026-07-31
 */

'use strict'

const ENABLE_CACHE = true;
const CACHE_TTL = 20 * 60 * 1000;
const TIMEOUT = 10000;

const CONFIG = {
  kw: {
    name: '酷我音乐',
    qualitys: { '128k': '0', '320k': '5', 'flac': '1' },
    api: 'https://oiapi.net/api/Kuwo?msg={keyword}&n=1&br={quality}',
    idField: ['rid', 'id', 'songmid', 'hash'],
    urlField: ['data.url', 'url', 'playUrl'],
    urlExtraField: ['data.rid'],   // kw 有时 URL 在别处
  },
  tx: {
    name: 'QQ音乐',
    qualitys: { '128k': '0', '320k': '1', 'flac': '2', 'flac24bit': '3', 'hires': '4', 'master': '5' },
    api: 'https://a.aa.cab/qq.music?msg={keyword}&n=1&type={quality}',
    idField: ['songmid', 'id', 'hash'],
    urlField: ['data.music', 'playUrl', 'url', 'data.url'],
  },
  wy: {
    name: '网易云音乐',
    qualitys: {
      '128k': 'standard', '320k': 'exhigh', 'flac': 'lossless',
      'hires': 'hires', 'atmos': 'jyeffect', 'atmos_plus': 'sky', 'master': 'jymaster',
    },
    api: 'https://api.bugpk.com/api/163_music?type=json&ids={id}&level={quality}',
    idField: ['id', 'songmid', 'hash'],
    urlField: ['url', 'data.url', 'playUrl'],
  },
};

const { EVENT_NAMES, request, on, send } = globalThis.lx;

const cache = Object.create(null);

function getCache(key) {
  if (!ENABLE_CACHE) return null;
  const entry = cache[key];
  if (!entry) return null;
  if (Date.now() > entry.expire) {
    delete cache[key];
    return null;
  }
  return entry.data;
}

function setCache(key, data) {
  if (!ENABLE_CACHE) return;
  cache[key] = { data, expire: Date.now() + CACHE_TTL };
}

const qualitys = Object.create(null);
const sources = Object.create(null);
const sourceKeys = Object.keys(CONFIG);

for (let i = 0, len = sourceKeys.length; i < len; i++) {
  const s = sourceKeys[i];
  const c = CONFIG[s];
  qualitys[s] = c.qualitys;
  sources[s] = {
    name: c.name,
    type: 'music',
    actions: ['musicUrl'],
    qualitys: Object.keys(c.qualitys),
  };
}

function httpRequest(url) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('请求超时')), TIMEOUT);
    request(url, {}, (err, resp) => {
      clearTimeout(timer);
      if (err) return reject(err);
      resolve(resp.body);
    });
  });
}

function getField(obj, fields) {
  for (let i = 0, len = fields.length; i < len; i++) {
    const parts = fields[i].split('.');
    let val = obj;
    let ok = true;
    for (let j = 0, jLen = parts.length; j < jLen; j++) {
      const p = parts[j];
      if (val && typeof val === 'object' && val[p] !== undefined) {
        val = val[p];
      } else {
        ok = false;
        break;
      }
    }
    if (ok && val !== undefined && val !== null) return val;
  }
  return undefined;
}

function getSongId(info, fields) {
  for (let i = 0, len = fields.length; i < len; i++) {
    const val = info[fields[i]];
    if (val) return val;
  }
  return '';
}

function safeParseJSON(data) {
  if (typeof data !== 'string') return data;
  try {
    return JSON.parse(data);
  } catch (e) {
    return null;
  }
}

async function tryApi(s, info, quality) {
  const c = CONFIG[s];
  const id = getSongId(info, c.idField);
  const keyword = info.name || info.songname || info.singer || '';
  const qv = qualitys[s][quality] || quality;

  let url = c.api
    .replace(/\{id\}/g, encodeURIComponent(id || ''))
    .replace(/\{keyword\}/g, encodeURIComponent(keyword))
    .replace(/\{quality\}/g, qv);

  const data = await httpRequest(url);
  const parsed = safeParseJSON(data);
  if (!parsed) return Promise.reject('响应解析失败');

  // 从响应中提取播放 URL
  const result = getField(parsed, c.urlField);
  if (result && typeof result === 'string' && result.startsWith('http')) {
    return result;
  }

  return Promise.reject('找不到播放链接');
}

// 音质降级链
const QUALITY_FALLBACK = {
  'master':     ['master', 'hires', 'flac24bit', 'flac', '320k', '128k'],
  'atmos_plus': ['atmos_plus', 'atmos', 'flac24bit', 'flac', '320k', '128k'],
  'atmos':      ['atmos', 'flac24bit', 'flac', '320k', '128k'],
  'hires':      ['hires', 'flac24bit', 'flac', '320k', '128k'],
  'flac24bit':  ['flac24bit', 'flac', '320k', '128k'],
  'flac':       ['flac', '320k', '128k'],
  '320k':       ['320k', '128k'],
  '128k':       ['128k'],
};

const apis = Object.create(null);
for (let i = 0, len = sourceKeys.length; i < len; i++) {
  const s = sourceKeys[i];
  const idFields = CONFIG[s].idField || [];
  const idLen = idFields.length;
  apis[s] = {
    async musicUrl(info, quality) {
      let id = '';
      for (let j = 0; j < idLen; j++) {
        const v = info[idFields[j]];
        if (v) { id = v; break; }
      }
      const key = s + '_' + (id || info.name) + '_' + quality;
      const cached = getCache(key);
      if (cached) return cached;

      // 按降级链逐级尝试
      const fallbackList = QUALITY_FALLBACK[quality] || [quality];
      for (let q = 0; q < fallbackList.length; q++) {
        const tryQuality = fallbackList[q];
        // 检查该平台是否支持此音质
        if (!qualitys[s][tryQuality] && !Object.values(qualitys[s]).includes(tryQuality)) continue;
        try {
          const result = await tryApi(s, info, tryQuality);
          setCache(key, result);
          return result;
        } catch (e) {
          // 降级继续
          continue;
        }
      }
      return Promise.reject('所有音质均失败');
    },
  };
}

on(EVENT_NAMES.request, ({ source, action, info }) => {
  if (action === 'musicUrl' && apis[source]) {
    return apis[source].musicUrl(info.musicInfo, qualitys[source][info.type]);
  }
  return Promise.reject('不支持');
});

send(EVENT_NAMES.inited, { openDevTools: false, sources });
