/**
 * @name 念心音源(解密版)
 * @description 音源更新，关注微信公众号: 念心小站
 * @version 1.0.1
 * @author 念心小站 & TZB679
 * @update_url https://gitee.com/nianxinxz1/emo-music/raw/master/wubian.json
 */

const {
  EVENT_NAMES: h,
  request: i,
  on: a,
  send: b
} = globalThis.lx;
const d = "1.0.1";
const c = "https://gitee.com/nianxinxz1/emo-music/raw/master/wubian.json";
const e = {
  kg: {
    "128k": "standard",
    "320k": "exhigh",
    flac: "lossless",
    master: "master",
    atmos: "atmos"
  },
  tx: {
    "128k": "standard",
    "320k": "exhigh",
    flac: "lossless",
    hires: "hires",
    master: "master",
    atmos: "atmos"
  },
  wy: {
    "128k": "standard",
    "320k": "exhigh",
    flac: "lossless",
    hires: "hires",
    jyeffect: "jyeffect",
    jymaster: "jymaster"
  },
  kw: {
    "128k": "standard",
    "320k": "exhigh",
    flac: "lossless"
  },
  mg: {
    "128k": "standard",
    "320k": "exhigh",
    flac: "lossless"
  }
};
const f = {
  kg: {
    musicUrl(e, a) {
      let b = "";
      const f = e.hash;
      console.log(a, f);
      b = "http://mcp.nianxinxz.com/share/ceshi/kg.php?id=" + f + "&level=" + a + "&type=mp3";
      return new Promise(c => {
        c(b);
      });
    }
  },
  tx: {
    musicUrl(e, a) {
      let b = "";
      const f = e.songmid;
      console.log(a, f);
      b = "http://mcp.nianxinxz.com/share/ceshi/tx.php?id=" + f + "&level=" + a + "&type=mp3";
      return new Promise(c => {
        c(b);
      });
    }
  },
  wy: {
    musicUrl(e, a) {
      let b = "";
      const f = e.songmid;
      console.log(a, f);
      b = "http://mcp.nianxinxz.com/share/ceshi/wy.php?id=" + f + "&level=" + a + "&type=mp3";
      return new Promise(c => {
        c(b);
      });
    }
  },
  kw: {
    musicUrl(e, a) {
      let b = "";
      const f = e.songmid;
      console.log(a, f);
      b = "http://mcp.nianxinxz.com/share/ceshi/kw.php?id=" + f + "&level=" + a + "&type=mp3";
      return new Promise(c => {
        c(b);
      });
    }
  },
  mg: {
    musicUrl(e, a) {
      let b = "";
      const f = e.songmid;
      console.log(a, f);
      b = "http://mcp.nianxinxz.com/share/ceshi/mg.php?id=" + f + "&level=" + a + "&type=mp3";
      return new Promise(c => {
        c(b);
      });
    }
  }
};
const g = (e, a) => {
  const f = e.split(".").map(Number);
  const c = a.split(".").map(Number);
  for (let d = 0; d < Math.max(f.length, c.length); d++) {
    const e = f[d] || 0;
    const a = c[d] || 0;
    if (e > a) {
      return 1;
    }
    if (e < a) {
      return -1;
    }
  }
  return 0;
};
const j = async () => {
  return new Promise((e, a) => {
    i(c, {
      method: "GET",
      timeout: 3000
    }, (a, f) => {
      if (a || f.statusCode !== 200) {
        console.log("检查更新失败:", a || f.statusMessage);
        e(null);
        return;
      }
      try {
        const a = f.body;
        if (g(d, a.version) < 0) {
          const b = {
            version: a.version,
            updateUrl: a.updateUrl,
            description: a.description || ""
          };
          e(b);
        } else {
          e(null);
        }
      } catch (a) {
        console.log("解析版本信息失败:", a);
        e(null);
      }
    });
  });
};
a(h.request, ({
  source: d,
  action: a,
  info: b
}) => {
  switch (a) {
    case "musicUrl":
      console.log(f[d].musicUrl(b.musicInfo, e[d][b.type]), d);
      return f[d].musicUrl(b.musicInfo, e[d][b.type]);
  }
});
j().then(e => {
  if (e) {
    const a = "发现新版本 v" + e.version + "\n" + (e.description ? "更新内容: " + e.description + "\n" : "") + "请更新后使用";
    const c = {
      log: a,
      updateUrl: e.updateUrl
    };
    b(h.updateAlert, c);
    console.log("发现新版本,需要更新,脚本将不会初始化:", e);
    return;
  } else {
    console.log("当前已是最新版本,正常初始化");
    b(h.inited, {
      openDevTools: false,
      sources: {
        kg: {
          name: "kg音乐",
          type: "music",
          actions: ["musicUrl"],
          qualitys: ["128k", "320k", "flac"]
        },
        tx: {
          name: "tx音乐",
          type: "music",
          actions: ["musicUrl"],
          qualitys: ["128k", "320k", "flac"]
        },
        wy: {
          name: "wy音乐",
          type: "music",
          actions: ["musicUrl"],
          qualitys: ["128k", "320k", "flac"]
        },
        kw: {
          name: "kw音乐",
          type: "music",
          actions: ["musicUrl"],
          qualitys: ["128k", "320k", "flac"]
        },
        mg: {
          name: "mg音乐",
          type: "music",
          actions: ["musicUrl"],
          qualitys: ["128k", "320k", "flac"]
        }
      }
    });
  }
}).catch(c => {
  console.log("检查更新出错,正常初始化:", c);
  b(h.inited, {
    openDevTools: false,
    sources: {
      kg: {
        name: "kg音乐",
        type: "music",
        actions: ["musicUrl"],
        qualitys: ["128k", "320k", "flac"]
      },
      tx: {
        name: "tx音乐",
        type: "music",
        actions: ["musicUrl"],
        qualitys: ["128k", "320k", "flac"]
      },
      wy: {
        name: "wy音乐",
        type: "music",
        actions: ["musicUrl"],
        qualitys: ["128k", "320k", "flac"]
      },
      kw: {
        name: "kw音乐",
        type: "music",
        actions: ["musicUrl"],
        qualitys: ["128k", "320k", "flac"]
      },
      mg: {
        name: "mg音乐",
        type: "music",
        actions: ["musicUrl"],
        qualitys: ["128k", "320k", "flac"]
      }
    }
  });
});