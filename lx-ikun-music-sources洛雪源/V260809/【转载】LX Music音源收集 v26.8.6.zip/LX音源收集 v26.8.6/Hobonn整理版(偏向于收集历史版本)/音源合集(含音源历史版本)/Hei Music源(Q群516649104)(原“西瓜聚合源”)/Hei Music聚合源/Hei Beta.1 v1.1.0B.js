/**
 * @name Hei Beta.1
 * @description 聚合自网上公开接口及音源，请低调使用
 * @version 1.1.0B
 * @author Compile by CatXiaolan
 */

const { EVENT_NAMES, request, on, send } = globalThis.lx

const qualitys = {
  kw: {
    '128k': '128',
    '320k': '320',
    flac: 'flac',
    flac24bit: 'flac24bit',
  },
  kg: {
    '128k': '128',
    '320k': '320',
    flac: 'flac',
    flac24bit: 'flac24bit',
  },
  tx: {
    '128k': '128',
    '320k': '320',
    flac: 'flac',
    flac24bit: 'flac24bit',
  },
  wy: {
    '128k': '128',
    '320k': '320',
    flac: 'flac',
    flac24bit: 'flac24bit',
  },
  mg: {
    '128k': '128',
    '320k': '320',
    flac: 'flac',
    flac24bit: 'flac24bit',
  },
}

const httpRequest = (url, options) => new Promise((resolve, reject) => {
  request(url, options, (err, resp) => {
    if (err) return reject(err)
    resolve(resp.body)
  })
})

const isValidUrl = function(url) {
  if (!url || typeof url !== 'string') return false
  if (url.indexOf('http://') !== 0 && url.indexOf('https://') !== 0) return false
  if (url.indexOf('panspace.kuwo.cn') !== -1) return false
  return true
}

const getSongId = function(musicInfo) {
  return musicInfo.hash || musicInfo.songmid || musicInfo.songId || musicInfo.id || musicInfo.rid || musicInfo.musicId || musicInfo.copyrightId || musicInfo.songid
}

const getPlatformSongId = function(platform, musicInfo) {
  if (platform === 'kg') return musicInfo.hash || musicInfo.songmid || musicInfo.id || musicInfo.rid || musicInfo.mid
  if (platform === 'tx') return musicInfo.songmid || musicInfo.strMediaMid || musicInfo.mediaId || musicInfo.id
  return musicInfo.songmid || musicInfo.id || musicInfo.songId || musicInfo.rid || musicInfo.hash
}

const qualityToLevel = function(quality) {
  var q = String(quality || '128k').toLowerCase()
  if (q === 'flac' || q === 'flac24bit') return 'lossless'
  if (q === '320k' || q === '192k') return 'exhigh'
  return 'standard'
}

const buildSearchKeyword = function(musicInfo) {
  var name = musicInfo.name || musicInfo.songName || ''
  var singer = musicInfo.singer || musicInfo.artist || ''
  if (name && singer) return name + ' ' + singer
  return name
}

// ========== API 源获取函数 ==========

// 长青SVIP - 全平台 (从混淆代码提取的真实URL路径含1后缀)
const CHANGQING_URLS = {
  kw: 'https://musicapi.haitangw.net/music1/kw.php?type=mp3&id={id}&level={level}',
  kg: 'https://music.haitangw.cc/kgqq1/kg.php?type=mp3&id={id}&level={level}',
  tx: 'http://175.27.166.236/kgqq1/qq.php?type=mp3&id={id}&level={level}',
  wy: 'http://175.27.166.236/wy1/wy.php?type=mp3&id={id}&level={level}',
  mg: 'https://music.haitangw.cc/musicapi1/mg.php?type=mp3&id={id}&level={level}',
}
const fetchChangqing = function(source, musicInfo, quality) {
  var songId = getPlatformSongId(source, musicInfo)
  if (!songId) return Promise.reject(new Error('长青SVIP: 歌曲ID不存在'))
  var template = CHANGQING_URLS[source]
  if (!template) return Promise.reject(new Error('长青SVIP: 不支持该平台'))
  var level = qualityToLevel(quality)
  var url = template.replace('{id}', encodeURIComponent(String(songId))).replace('{level}', encodeURIComponent(level))
  return Promise.resolve(url)
}

// 念心SVIP - kw/tx/wy/mg (从混淆代码提取的真实URL)
const NIANXIN_URLS = {
  kw: 'https://mcp.nianxinxz.com/share/ceshi/kw.php?id={id}&level={level}&type=mp3',
  tx: 'https://mcp.nianxinxz.com/share/ceshi/tx.php?id={id}&level={level}&type=mp3',
  wy: 'https://mcp.nianxinxz.com/share/ceshi/wy.php?id={id}&level={level}&type=mp3',
  mg: 'https://mcp.nianxinxz.com/share/ceshi/mg.php?id={id}&level={level}&type=mp3',
}
const fetchNianxin = function(source, musicInfo, quality) {
  var songId = getPlatformSongId(source, musicInfo)
  if (!songId) return Promise.reject(new Error('念心SVIP: 歌曲ID不存在'))
  var template = NIANXIN_URLS[source]
  if (!template) return Promise.reject(new Error('念心SVIP: 不支持该平台'))
  var level = qualityToLevel(quality)
  var url = template.replace('{id}', encodeURIComponent(String(songId))).replace('{level}', encodeURIComponent(level))
  return Promise.resolve(url)
}

// 聆澜音源 - kw/kg/tx/wy
const fetchLinglan = function(source, musicInfo, quality) {
  var songId = musicInfo.hash || musicInfo.songmid
  if (!songId) return Promise.reject(new Error('聆澜: 歌曲ID不存在'))
  var apiUrl = 'https://source.shiqianjiang.cn/api/music/url?source=' + source + '&songId=' + encodeURIComponent(String(songId)) + '&quality=' + encodeURIComponent(quality)
  return httpRequest(apiUrl, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': 'CERU_KEY-1709B0C2AC900B075CBF6A7B36E0DE1F',
    },
  }).then(function(body) {
    if (!body || isNaN(Number(body.code))) throw new Error('聆澜: unknown error')
    if (body.code === 200) {
      if (isValidUrl(body.url)) return body.url
      throw new Error('聆澜: invalid url')
    }
    throw new Error('聆澜: ' + (body.message || '未知错误'))
  })
}

// chksz - wy
const fetchChksz = function(source, musicInfo, quality) {
  if (source !== 'wy') return Promise.reject(new Error('chksz 仅支持 wy'))
  var songId = getSongId(musicInfo)
  if (!songId) return Promise.reject(new Error('chksz: 歌曲ID不存在'))
  var levelMap = { '128k': 'standard', '320k': 'exhigh', 'flac': 'lossless', 'flac24bit': 'jymaster' }
  var level = levelMap[quality] || 'standard'
  return httpRequest('https://api.chksz.top/api/163_music?id=' + songId + '&level=' + level, {
    method: 'GET',
    headers: { 'Referer': 'https://cp.chksz.top/' },
  }).then(function(body) {
    if (body && body.code === 200 && body.data && body.data.url) return body.data.url
    throw new Error('chksz 获取失败')
  })
}

// HUIBQ - tx
const fetchHuibq = function(source, musicInfo, quality) {
  if (source !== 'tx') return Promise.reject(new Error('HUIBQ 仅支持 tx'))
  var songId = getSongId(musicInfo)
  if (!songId) return Promise.reject(new Error('HUIBQ: 歌曲ID不存在'))
  var supportedQualities = ['320k', '192k', '128k']
  var targetQuality = supportedQualities.indexOf(quality) !== -1 ? quality : '320k'
  return httpRequest('https://lxmusicapi.onrender.com/url/' + source + '/' + songId + '/' + targetQuality, {
    method: 'GET',
    headers: { 'X-Request-Key': 'share-v3' },
  }).then(function(body) {
    if (!body || isNaN(Number(body.code))) throw new Error('HUIBQ: unknow error')
    if (body.code === 0) {
      if (isValidUrl(body.url)) return body.url
      throw new Error('HUIBQ: invalid url')
    }
    throw new Error('HUIBQ: ' + (body.msg || 'unknow error'))
  })
}

// 溯音酷我 - kw
const fetchSuyinKuwo = function(source, musicInfo, quality) {
  if (source !== 'kw') return Promise.reject(new Error('溯音酷我 仅支持 kw'))
  var keyword = buildSearchKeyword(musicInfo)
  if (!keyword) return Promise.reject(new Error('溯音酷我: 缺少歌曲名'))
  var brMap = { 'flac': 1, 'flac24bit': 1, '320k': 5, '128k': 7 }
  var br = brMap[quality] || 7
  return httpRequest('https://oiapi.net/api/Kuwo?msg=' + encodeURIComponent(keyword) + '&n=1&br=' + br, {
    method: 'GET',
  }).then(function(body) {
    if (body && body.data && body.data.url && isValidUrl(body.data.url)) return body.data.url
    throw new Error('溯音酷我 获取失败')
  })
}

// gdstudio - wy
const fetchGdstudio = function(source, musicInfo, quality) {
  if (source !== 'wy') return Promise.reject(new Error('gdstudio 仅支持 wy'))
  var songId = getSongId(musicInfo)
  if (!songId) return Promise.reject(new Error('gdstudio: 歌曲ID不存在'))
  var brMap = { '128k': '128', '320k': '320', 'flac': '740', 'flac24bit': '999' }
  var br = brMap[quality] || '320'
  return httpRequest('https://music-api.gdstudio.xyz/api.php?types=url&source=netease&id=' + songId + '&br=' + br, {
    method: 'GET',
  }).then(function(body) {
    if (body && body.url && isValidUrl(body.url)) return body.url
    throw new Error('gdstudio 获取失败')
  })
}

// 溯音咪咕 - mg
const fetchSuyinMigu = function(source, musicInfo, quality) {
  if (source !== 'mg') return Promise.reject(new Error('溯音咪咕 仅支持 mg'))
  var keyword = buildSearchKeyword(musicInfo)
  if (!keyword) return Promise.reject(new Error('溯音咪咕: 缺少歌曲名'))
  return httpRequest('https://api.xcvts.cn/api/music/migu?gm=' + encodeURIComponent(keyword) + '&n=1&num=1&type=json', {
    method: 'GET',
  }).then(function(body) {
    if (body && body.code === 200) {
      var url = body.music_url || body.musicInfo
      if (url && isValidUrl(url)) return url
    }
    throw new Error('溯音咪咕 获取失败')
  })
}

// cenguigui - kw
const fetchCenguigui = function(source, musicInfo, quality) {
  if (source !== 'kw') return Promise.reject(new Error('cenguigui 仅支持 kw'))
  var songId = getSongId(musicInfo)
  if (!songId) return Promise.reject(new Error('cenguigui: 歌曲ID不存在'))
  var levelMap = { '128k': '128k', '320k': '320k', 'flac': 'lossless', 'flac24bit': 'lossless' }
  var level = levelMap[quality] || '320k'
  return httpRequest('https://kw-api.cenguigui.cn?id=' + songId + '&type=song&format=json&level=' + level, {
    method: 'GET',
  }).then(function(body) {
    var realUrl
    if (body) {
      if (body.data && body.data.url) realUrl = body.data.url
      else if (body.url) realUrl = body.url
    }
    if (isValidUrl(realUrl)) return realUrl
    throw new Error('cenguigui 获取失败')
  })
}

// ========== API 源列表 ==========
const API_SOURCES = [
  { name: '长青SVIP',  fetch: fetchChangqing,  sources: ['kw', 'kg', 'tx', 'wy', 'mg'] },
  { name: '念心SVIP',  fetch: fetchNianxin,    sources: ['kw', 'tx', 'wy', 'mg'] },
  { name: '溯音酷我',   fetch: fetchSuyinKuwo,  sources: ['kw'] },
  { name: 'chksz',      fetch: fetchChksz,      sources: ['wy'] },
  { name: 'HUIBQ',      fetch: fetchHuibq,      sources: ['tx'] },
  { name: '溯音咪咕',   fetch: fetchSuyinMigu,  sources: ['mg'] },
  { name: 'gdstudio',   fetch: fetchGdstudio,   sources: ['wy'] },
]

// ========== 核心逻辑 ==========
const handleGetMusicUrl = function(source, musicInfo, quality) {
  var errors = []
  var trySource = function(index) {
    if (index >= API_SOURCES.length) {
      return Promise.reject(new Error('所有API源均失败:\n' + errors.join('\n')))
    }
    var apiSource = API_SOURCES[index]
    if (apiSource.sources.indexOf(source) === -1) return trySource(index + 1)
    return apiSource.fetch(source, musicInfo, quality).then(function(url) {
      if (url && isValidUrl(url)) return url
      return trySource(index + 1)
    }).catch(function(e) {
      errors.push(apiSource.name + ': ' + (e.message || e))
      return trySource(index + 1)
    })
  }
  return trySource(0)
}

// ========== apis 对象（对齐官方示例结构）==========
const apis = {
  kw: {
    musicUrl: function(musicInfo, quality) {
      return handleGetMusicUrl('kw', musicInfo, quality)
    },
  },
  kg: {
    musicUrl: function(musicInfo, quality) {
      return handleGetMusicUrl('kg', musicInfo, quality)
    },
  },
  tx: {
    musicUrl: function(musicInfo, quality) {
      return handleGetMusicUrl('tx', musicInfo, quality)
    },
  },
  wy: {
    musicUrl: function(musicInfo, quality) {
      return handleGetMusicUrl('wy', musicInfo, quality)
    },
  },
  mg: {
    musicUrl: function(musicInfo, quality) {
      return handleGetMusicUrl('mg', musicInfo, quality)
    },
  },
}

// 注册应用 API 请求事件
on(EVENT_NAMES.request, function(params) {
  var source = params.source
  var action = params.action
  var info = params.info
  switch (action) {
    case 'musicUrl':
      return apis[source].musicUrl(info.musicInfo, qualitys[source][info.type]).catch(function(err) {
        console.log(err)
        return Promise.reject(err)
      })
    default:
      console.error('action(' + action + ') not support')
      return Promise.reject('action not support')
  }
})

// 脚本初始化完成后发送 inited 事件告知应用
send(EVENT_NAMES.inited, {
  sources: {
    kw: {
      name: '酷我音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    kg: {
      name: '酷狗音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    tx: {
      name: 'QQ音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    wy: {
      name: '网易云音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
    mg: {
      name: '咪咕音乐',
      type: 'music',
      actions: ['musicUrl'],
      qualitys: ['128k', '320k', 'flac', 'flac24bit'],
    },
  },
})
