/*!
 * @name 音源
 */

const ENABLE_CACHE = false;
const CACHE_TTL = 20 * 60 * 1000;
const TIMEOUT = 10000;

const CONFIG = {
  kw: {
    name: '酷我音乐',
    qualitys: { '128k': '0', '320k': '5', 'flac': '1' },
    api: 'https://oiapi.net/api/Kuwo?msg={keyword}&n=1&br={quality}',
    idField: ['rid', 'id', 'songmid', 'hash'],
    urlField: ['data.url', 'url', 'playUrl'],
  },
  kg: {
    name: '酷狗音乐',
    qualitys: { '128k': '128', '320k': '320', 'flac': 'flac' },
    api: '',
    idField: ['hash', 'songmid', 'id', 'rid'],
    urlField: ['url', 'data.url', 'playUrl'],
  },
  tx: {
    name: 'QQ音乐',
    qualitys: { '128k': '0', '320k': '1', 'flac': '2','flac24bit':'3','hires':'4','master':'5' },
    api: 'https://a.aa.cab/qq.music?msg={keyword}&n=1&type={quality}',
    idField: ['songmid', 'id', 'hash'],
    urlField: ['data.music','playUrl', 'url', 'data.url'],
  },
  wy: {
    name: '网易云音乐',
    qualitys: { '128k': 'standard', '320k': 'exhigh', 'flac': 'lossless' ,'hires':'hires','atmos':'jyeffect','atmos_plus':'sky','master':'jymaster'},
    api: 'https://api.bugpk.com/api/163_music?type=json&ids={id}&level={quality}',
    idField: ['id', 'songmid', 'hash'],
    urlField: ['url', 'data.url', 'playUrl'],
  },
  mg: {
    name: '咪咕音乐',
    qualitys: { '128k': '128', '320k': '320', 'flac': 'flac' },
    api: 'https://你的咪咕API.com?id={id}&quality={quality}',
    idField: ['id', 'songmid', 'hash'],
    urlField: ['url', 'data.url', 'playUrl'],
  },
}

const { EVENT_NAMES, request, on, send } = globalThis.lx;

const cache = Object.create(null);

function getCache(key) {
  if (!ENABLE_CACHE) return null;
  const entry = cache[key];
  if (!entry) return null;
  if (Date.now() > entry.expire) {
    delete cache[key];
    return null;
  }
  return entry.data;
}

function setCache(key, data) {
  if (!ENABLE_CACHE) return;
  cache[key] = { data, expire: Date.now() + CACHE_TTL };
}

const qualitys = Object.create(null);
const sources = Object.create(null);
const sourceKeys = Object.keys(CONFIG);

for (let i = 0, len = sourceKeys.length; i < len; i++) {
  const s = sourceKeys[i];
  const c = CONFIG[s];
  qualitys[s] = c.qualitys;
  sources[s] = {
    name: c.name,
    type: 'music',
    actions: ['musicUrl'],
    qualitys: Object.keys(c.qualitys),
  };
}
qualitys.local = {};
sources.local = {
  name: '本地音乐',
  type: 'music',
  actions: ['musicUrl', 'lyric', 'pic'],
  qualitys: [],
};

function httpRequest(url) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('请求超时')), TIMEOUT);
    request(url, {}, (err, resp) => {
      clearTimeout(timer);
      err ? reject(err) : resolve(resp.body);
    });
  });
}

function getField(obj, fields) {
  for (let i = 0, len = fields.length; i < len; i++) {
    const parts = fields[i].split('.');
    let val = obj;
    let ok = true;
    for (let j = 0, jLen = parts.length; j < jLen; j++) {
      const p = parts[j];
      if (val && typeof val === 'object' && val[p] !== undefined) {
        val = val[p];
      } else {
        ok = false;
        break;
      }
    }
    if (ok && val !== undefined && val !== null) return val;
  }
  return undefined;
}

function getSongId(info, fields) {
  for (let i = 0, len = fields.length; i < len; i++) {
    const val = info[fields[i]];
    if (val) return val;
  }
  return '';
}

async function tryApi(s, info, quality) {
  const c = CONFIG[s];
  const id = getSongId(info, c.idField);
  if (!id) return Promise.reject('找不到歌曲ID');
  const qv = qualitys[s][quality] || quality;
  const url = c.api.replace(/\{id\}/g, id).replace(/\{keyword\}/g, encodeURIComponent(info.name||info.songname||'')).replace(/\{quality\}/g, qv);
  const data = await httpRequest(url);
  const parsed = typeof data === 'string' ? JSON.parse(data) : data;
  const result = getField(parsed, c.urlField);
  return (result && typeof result === 'string' && result.startsWith('http'))
    ? result
    : Promise.reject('找不到播放链接');
}

const apis = Object.create(null);
for (let i = 0, len = sourceKeys.length; i < len; i++) {
  const s = sourceKeys[i];
  const idFields = CONFIG[s].idField || [];
  const idLen = idFields.length;
  apis[s] = {
    async musicUrl(info, quality) {
      let id = '';
      for (let j = 0; j < idLen; j++) {
        const v = info[idFields[j]];
        if (v) { id = v; break; }
      }
      const key = s + '_' + (id || info.name) + '_' + quality;
      const cached = getCache(key);
      if (cached) return cached;
      const result = await tryApi(s, info, quality);
      setCache(key, result);
      return result;
    },
  };
}

on(EVENT_NAMES.request, ({ source, action, info }) => {
  if (action === 'musicUrl' && apis[source]) {
    return apis[source].musicUrl(info.musicInfo, qualitys[source][info.type]);
  }
  return Promise.reject('不支持');
});

send(EVENT_NAMES.inited, { openDevTools: false, sources });