/*!
 * @name 墨澜音乐源
 * @description Q音音源，最高支持母带（需自行填写uin和musickey）
 * @version 1.0.0
 * @author 白姬9527
 */

// 播放会员歌曲需要填写下方两个参数
// UIN: 你的QQ号
// MUSICKEY: 登录 y.qq.com 后，从Cookie中获取 qqmusic_key 的值建议从lx-x中登录获取填写

const UIN = ""
const MUSICKEY = ""

const DEV_ENABLE = false

const QUALITY_MAP = {
  "128k": "M500",
  "320k": "M800",
  "flac": "F000",
  "flac24bit": "F000",
  "atmos": "Q000",
  "atmos_plus": "Q001",
  "master": "AI00",
}

const EXT_MAP = {
  "M500": ".mp3",
  "M800": ".mp3",
  "F000": ".flac",
  "Q000": ".flac",
  "Q001": ".flac",
  "AI00": ".flac",
}

const { EVENT_NAMES, request, on, send, utils, env, version } = globalThis.lx

const httpFetch = (url, options = { method: "GET" }) => {
  return new Promise((resolve, reject) => {
    request(url, options, (err, resp) => {
      if (err) return reject(err)
      resolve(resp)
    })
  })
}

/**
 * QQ音乐 g_tk (hash33) 算法
 * @param {string} str - 需要计算hash的字符串（MUSICKEY）
 * @returns {number} g_tk值
 */
function hash33(str) {
  let h = 5381
  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) + h + str.charCodeAt(i)) | 0
  }
  return 2147483647 & h
}

const handleGetMusicUrl = async (source, musicInfo, quality) => {
  if (source !== "tx") throw new Error("不支持的音源")

  // 获取歌曲ID（参考FL音源：使用songmid和strMediaMid）
  const songmid = musicInfo.songmid || musicInfo.hash
  const strMediaMid = musicInfo.strMediaMid || musicInfo.songmid || musicInfo.hash
  if (!songmid) throw new Error("缺少歌曲ID")

  const qualityCode = QUALITY_MAP[quality]
  if (!qualityCode) throw new Error("不支持的音质: " + quality)

  const ext = EXT_MAP[qualityCode]
  // 参考FL音源：使用 strMediaMid 生成 filename（只使用一次，不是两次songmid）
  const filename = `${qualityCode}${strMediaMid}${ext}`

  const hasLogin = UIN && MUSICKEY

  // 参考FL音源：使用固定guid '10000'
  const guid = "10000"

  // 构建comm参数（参考FL音源：简洁的comm）
  const comm = {
    uin: hasLogin ? UIN : "0",
    format: "json",
    ct: 24,
    cv: 0,
  }

  if (hasLogin) {
    const gtk = hash33(MUSICKEY)
    comm.g_tk = gtk
    comm.g_tk_new_20200303 = gtk
  }

  // 参考FL音源：使用 vkey.GetVkeyServer/CgiGetVkey 模块和方法
  // 参数简洁，只包含必要字段
  const reqData = {
    req_0: {
      module: "vkey.GetVkeyServer",
      method: "CgiGetVkey",
      param: {
        filename: [filename],
        guid,
        songmid: [songmid],
        songtype: [0],
        uin: hasLogin ? UIN : "0",
        loginflag: 1,
        platform: "20",
      },
    },
    loginUin: hasLogin ? UIN : "0",
    comm,
  }

  // 参考FL音源：使用GET请求，数据通过URL的data参数传递
  // 注意：FL音源未使用encodeURIComponent，但为了安全我们进行编码
  const dataStr = JSON.stringify(reqData)
  const targetUrl = `https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&data=${encodeURIComponent(dataStr)}`

  // 参考FL音源：添加channel和uid请求头
  const headers = {
    channel: "0146951",
    uid: 1234,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Referer: "https://y.qq.com/",
  }

  // 添加Cookie头（用于VIP歌曲认证）
  if (hasLogin) {
    headers["Cookie"] = `uin=${UIN}; qqmusic_uin=${UIN}; qm_keyst=${MUSICKEY}; qqmusic_key=${MUSICKEY}`
  }

  const resp = await httpFetch(targetUrl, {
    method: "GET",
    headers,
    follow_max: 5,
  })

  if (!resp || !resp.body) throw new Error("请求无响应")

  let body = resp.body
  if (typeof body === "string") {
    try { body = JSON.parse(body) } catch (e) { throw new Error("响应解析失败") }
  }

  // 检查顶层code
  if (body.code !== 0) throw new Error("请求失败: " + (body.message || body.code))

  // 检查req_0
  const req0 = body.req_0 || {}
  if (req0.code === 104003 || req0.code === 104004) throw new Error("需要VIP权限")
  if (req0.code !== 0) throw new Error("业务错误: " + req0.code)

  const d = req0.data
  if (!d) throw new Error("响应数据为空")

  const mi = Array.isArray(d.midurlinfo) ? d.midurlinfo[0] : null
  if (!mi) throw new Error("获取播放链接失败: 无歌曲信息")

  const purl = mi.purl
  // 参考FL音源：purl为空表示VIP歌曲
  if (!purl || purl === "") {
    if (mi.result === 104003 || mi.result === 104004) throw new Error("需要VIP权限")
    throw new Error("获取播放链接失败: purl为空")
  }

  // 构建完整URL
  if (/^https?:\/\//i.test(purl)) return purl

  const sip = Array.isArray(d.sip) && d.sip.length > 0 ? d.sip : null
  if (sip) return sip[Math.floor(Math.random() * sip.length)] + purl
  return "https://isure.stream.qqmusic.qq.com/" + purl
}

const musicSources = {
  tx: {
    name: "tx",
    type: "music",
    actions: ["musicUrl"],
    qualitys: ["128k", "320k", "flac", "flac24bit", "atmos", "atmos_plus", "master"],
  },
}

on(EVENT_NAMES.request, ({ action, source, info }) => {
  if (action === "musicUrl") return handleGetMusicUrl(source, info.musicInfo, info.type)
  return Promise.reject("action not support")
})

send(EVENT_NAMES.inited, { status: true, openDevTools: DEV_ENABLE, sources: musicSources })